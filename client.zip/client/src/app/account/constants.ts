export class Constants {
  public static apiRoot = "https://localhost:9000";
  public static clientRoot = "http://localhost:4200";
  public static idpAuthority = "https://localhost:9009"
  public static clientId = "angular-client";
}
