import { Component } from '@angular/core';

@Component({
  selector: 'app-un-authenticated',
  templateUrl: './un-authenticated.component.html',
  styleUrls: ['./un-authenticated.component.scss']
})
export class UnAuthenticatedComponent {

}
