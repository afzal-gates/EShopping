export interface IType {
  id: string;
  name: string;
}
