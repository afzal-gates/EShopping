export class StoreParams {
  brandId = '';
  typeId = '';
  sort = '';
  pageNumber = 1;
  pageSize = 10;
  search?: string;
}
