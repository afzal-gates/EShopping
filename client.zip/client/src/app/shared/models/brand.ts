export interface IBrand {
  id: string;
  name: string;
}
